# fungi_nuke
Cull the mycus.
