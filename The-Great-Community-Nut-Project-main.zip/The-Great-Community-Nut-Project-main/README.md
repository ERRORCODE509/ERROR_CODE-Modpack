# **The-Great-Community-Nut-Project *v0.1 Alpha***
## *A community-assisted, nut-based total conversion mod that nobody asked for, but we made anyway.*
As you can tell, this mod is all about nuts. Though there is a heavy emphasis on pine nuts (the superior form of nut), other types of nuts are included as well. **Adding items, crafting recipes, monsters, locations (soon), mutations (soon), spells (eventually), NPCs (in the far future), and more, this mod is sure to strike anyone with a nut allergy dead upon starting the game.** Will you become one with the Nut, or reject its wisdom and join the disgusting, heretical mycus? The choice is yours!

This mod is under active development, and all features are subject to change. More content ***will*** be added.

There is a GitHub project board where you can monitor progress here: https://github.com/users/ERRORCODE509/projects/2

Found a bug or want to suggest a feature? Setup an issue for it here: https://github.com/ERRORCODE509/The-Great-Community-Nut-Project/issues

Made a change that you want included in the mod? Setup a pull request here: https://github.com/ERRORCODE509/The-Great-Community-Nut-Project/pulls
